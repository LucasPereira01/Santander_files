import{a}from"./chunk-2VPBLDOS.js";import"./chunk-HRHSODLN.js";import"./chunk-5RMWWPL7.js";import"./chunk-TYWQJ4NF.js";import"./chunk-V4QFN6JK.js";export{a as ParametrizadorComponent};
